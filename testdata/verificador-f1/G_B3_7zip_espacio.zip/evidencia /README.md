# X-39 Notaría — Bundle de evidencia / Evidence bundle

Acuerdo / Agreement: 31e1cf09a5b2a74cd978
Hash de la prueba / Proof hash (SHA-256): 7e897e5b6a8dcdd2ef2a8411365e02e88c9f58407fd84e14f6fdefa5c2a32cf6

Este bundle es autocontenido: NO necesitas confiar en X-39 ni en ningun servidor para verificarlo.
This bundle is self-contained: you do NOT need to trust X-39 or any server to verify it.

## Contenido / Contents

- `proof.json`       Payload canonico sellado (los bytes exactos que se firmaron y anclaron) / canonical sealed payload (the exact bytes that were signed and anchored)
- `proof.json.ots`   Prueba OpenTimestamps (ancla en Bitcoin) / OpenTimestamps proof (Bitcoin anchor)
- `signatures.json`  Firmas ML-DSA-87 (FIPS-204) y claves publicas / ML-DSA-87 signatures and public keys
- `README.md`        Esta guia / this guide

## 1. Integridad / Integrity

```
sha256sum proof.json
```
Debe coincidir con / must equal: `7e897e5b6a8dcdd2ef2a8411365e02e88c9f58407fd84e14f6fdefa5c2a32cf6`

## 2. Fecha anclada en Bitcoin / Bitcoin-anchored date

```
pip install opentimestamps-client
ots verify proof.json.ots
```
Nota: `ots verify` completo requiere un nodo Bitcoin local (verificacion 100% trustless). Sin nodo, usa `ots info proof.json.ots` para inspeccionar la atestacion de bloque / full `ots verify` requires a local Bitcoin node; without one, use `ots info` to inspect the block attestation.
Alternativa sin instalar nada / no-install alternative: sube `proof.json` y `proof.json.ots` a https://opentimestamps.org (verificador independiente).
Si el estado es "pending", el ancla espera confirmacion en bloque; reintenta mas tarde / if "pending", retry later:
```
ots upgrade proof.json.ots && ots verify proof.json.ots
```

## 3. Firma post-cuantica / Post-quantum signature (ML-DSA-87, FIPS-204, co-firma COLD air-gapped)

> La clave WARM (operador, servidor) fue RETIRADA el 2026-07-16 (SEC-003). Las firmas WARM de acuerdos
> anteriores siguen siendo verificables: la clave publica va embebida en `signatures.json`. En acuerdos
> nuevos, la autoria post-cuantica la aporta exclusivamente la co-firma COLD (sk air-gapped, nunca en red).
> The WARM (server-side operator) key was RETIRED on 2026-07-16 (SEC-003). Historical WARM signatures remain
> verifiable (public key embedded in `signatures.json`). For new agreements, post-quantum authorship is
> provided exclusively by the COLD co-signature (air-gapped sk, never networked).

Huella COLD esperada / expected COLD fingerprint: `8453a25a41d6fe8fcb5647600f042a7c303daaca79b80928534025711981c6a1`
CONTRASTALA por un canal independiente de este ZIP (la web de X-39, un correo previo): un bundle falso puede traer su propia clave y su propia huella, coherentes entre si. / CROSS-CHECK it out-of-band: a forged bundle can ship its own key and matching fingerprint.

```
pip install pqcrypto
python3 verify_mldsa.py
```
Contenido de `verify_mldsa.py` / contents:
```python
import json, base64, hashlib
from pqcrypto.sign import ml_dsa_87

# Huella de la clave COLD de X-39. Contrastala fuera de este bundle (ver README).
COLD_FP = "8453a25a41d6fe8fcb5647600f042a7c303daaca79b80928534025711981c6a1"

def verify_ok(pk, msg, sig):
    # pqcrypto >= 1.0.0 devuelve None si la firma es valida y LANZA excepcion si no;
    # versiones previas devuelven True/False. Esto cubre ambas convenciones.
    try:
        return ml_dsa_87.verify(pk, msg, sig) is not False
    except Exception:
        return False

s = json.load(open("signatures.json"))
p = open("proof.json", "rb").read()
for tier in ("warm", "cold"):
    t = s.get(tier)
    if not t:
        continue
    pk = base64.b64decode(t["public_key_b64"])
    sig = base64.b64decode(t["signature_b64"])
    valid = verify_ok(pk, p, sig)
    bad = bytearray(sig)
    bad[0] ^= 1
    if valid and verify_ok(pk, p, bytes(bad)):
        print("AVISO: esta instalacion acepta una firma ALTERADA; veredicto no fiable")
        valid = False
    fp = hashlib.sha256(pk).hexdigest()
    print(tier.upper(), "ML-DSA-87:", "VALID" if valid else "INVALID", "| huella/fp:", fp)
    if tier == "cold":
        print("  clave COLD", "RECONOCIDA de X-39" if fp == COLD_FP else "NO RECONOCIDA: NO es la autoridad de X-39")
    else:
        print("  WARM informativa: clave de servidor retirada 2026-07-16 (SEC-003), no acredita autoria")
```

### 3.5 Firmas por mensaje / Per-message signatures (X39-NOTARIA-3)

Si `chat_chain.json` incluye `sig_b64` en sus entradas, cada mensaje del chat fue firmado Ed25519 por su autor sobre el string `x39msg:v3:<agreement_id>:<content_hash>:<cts>`. Las pubkeys estan ancladas en `proof.json` (`sig_keys`).
If entries carry `sig_b64`, each chat message was Ed25519-signed by its author over that exact string; the public keys are anchored inside `proof.json` (`sig_keys`).

## 4. Vinculo con el documento original / Link to the original document

`proof.json` contiene `content_hash`: el SHA-256 del documento original, que SOLO las partes poseen (nunca se subio al servidor). Calcula el SHA-256 de tu copia local y comparalo.
`proof.json` contains `content_hash`: the SHA-256 of the original document, held ONLY by the parties (it was never uploaded). Hash your local copy and compare.

---
Verificados los 4 pasos, tienes evidencia matematica de existencia, integridad, fecha y autoria — sin depender de ningun servidor, empresa o pais.
With all 4 steps verified, you hold mathematical evidence of existence, integrity, date and authorship — with no dependence on any server, company or country.
