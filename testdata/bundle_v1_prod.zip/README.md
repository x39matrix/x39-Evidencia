# X-39 Notaría — Bundle de evidencia / Evidence bundle

Acuerdo / Agreement: demo0000demo0001
Hash de la prueba / Proof hash (SHA-256): 9cb107d9260460f260aead0514bdcdc94bcb372fd02742fbe5d59ad25ad59fd9

Este bundle es autocontenido: NO necesitas confiar en X-39 ni en ningun servidor para verificarlo.
This bundle is self-contained: you do NOT need to trust X-39 or any server to verify it.

## Contenido / Contents

- `proof.json`       Payload canonico sellado (los bytes exactos que se firmaron y anclaron) / canonical sealed payload (the exact bytes that were signed and anchored)
- `proof.json.ots`   Prueba OpenTimestamps (ancla en Bitcoin) / OpenTimestamps proof (Bitcoin anchor)
- `signatures.json`  Firmas ML-DSA-87 (FIPS-204) y claves publicas / ML-DSA-87 signatures and public keys
- `README.md`        Esta guia / this guide

## 1. Integridad / Integrity

```
sha256sum proof.json
```
Debe coincidir con / must equal: `9cb107d9260460f260aead0514bdcdc94bcb372fd02742fbe5d59ad25ad59fd9`

## 2. Fecha anclada en Bitcoin / Bitcoin-anchored date

```
pip install opentimestamps-client
ots verify proof.json.ots
```
Nota: `ots verify` completo requiere un nodo Bitcoin local (verificacion 100% trustless). Sin nodo, usa `ots info proof.json.ots` para inspeccionar la atestacion de bloque / full `ots verify` requires a local Bitcoin node; without one, use `ots info` to inspect the block attestation.
Alternativa sin instalar nada / no-install alternative: sube `proof.json` y `proof.json.ots` a https://opentimestamps.org (verificador independiente).
Si el estado es "pending", el ancla espera confirmacion en bloque; reintenta mas tarde / if "pending", retry later:
```
ots upgrade proof.json.ots && ots verify proof.json.ots
```

## 3. Firma post-cuantica / Post-quantum signature (ML-DSA-87, FIPS-204, co-firma COLD air-gapped)

> La clave WARM (operador, servidor) fue RETIRADA el 2026-07-16 (SEC-003). Las firmas WARM de acuerdos
> anteriores siguen siendo verificables: la clave publica va embebida en `signatures.json`. En acuerdos
> nuevos, la autoria post-cuantica la aporta exclusivamente la co-firma COLD (sk air-gapped, nunca en red).
> The WARM (server-side operator) key was RETIRED on 2026-07-16 (SEC-003). Historical WARM signatures remain
> verifiable (public key embedded in `signatures.json`). For new agreements, post-quantum authorship is
> provided exclusively by the COLD co-signature (air-gapped sk, never networked).

```
pip install pqcrypto
python3 verify_mldsa.py
```
Contenido de `verify_mldsa.py` / contents:
```python
import json, base64
from pqcrypto.sign import ml_dsa_87
s = json.load(open("signatures.json"))
p = open("proof.json", "rb").read()
for tier in ("warm", "cold"):
    t = s.get(tier)
    if not t:
        continue
    ok = ml_dsa_87.verify(base64.b64decode(t["public_key_b64"]), p, base64.b64decode(t["signature_b64"]))
    print(tier.upper(), "ML-DSA-87:", "VALID" if ok else "INVALID")
```

## 4. Vinculo con el documento original / Link to the original document

`proof.json` contiene `content_hash`: el SHA-256 del documento original, que SOLO las partes poseen (nunca se subio al servidor). Calcula el SHA-256 de tu copia local y comparalo.
`proof.json` contains `content_hash`: the SHA-256 of the original document, held ONLY by the parties (it was never uploaded). Hash your local copy and compare.

---
Verificados los 4 pasos, tienes evidencia matematica de existencia, integridad, fecha y autoria — sin depender de ningun servidor, empresa o pais.
With all 4 steps verified, you hold mathematical evidence of existence, integrity, date and authorship — with no dependence on any server, company or country.
