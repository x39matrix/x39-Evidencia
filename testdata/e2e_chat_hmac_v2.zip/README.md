# X-39 Notaria - Bundle de evidencia / Evidence bundle

Acuerdo / Agreement: bc1edb022c7d61952fb9

Bundle autocontenido: NO necesitas confiar en X-39 ni en ningun servidor para verificarlo.

## Contenido
- proof.json       Payload canonico sellado (bytes exactos firmados y anclados)
- proof.json.ots   Prueba OpenTimestamps (ancla en Bitcoin)
- signatures.json  Firmas ML-DSA-87 (FIPS-204) y claves publicas
- README.md        Esta guia

proof.json incluye 'files' (sha256 de README.md): esta guia queda cubierta
por el ancla de Bitcoin. signatures.json se verifica por criptografia (proof_hash y firmas).

## 1. Integridad
   sha256sum proof.json  -> debe igualar el proof_hash de signatures.json.

## 2. Fecha en Bitcoin
   ots verify proof.json.ots   (sin nodo: ots info, o https://opentimestamps.org)

## 3. Firma post-cuantica (ML-DSA-87, FIPS-204)
WARM (operador) RETIRADA 2026-07-16 (SEC-003); firmas WARM historicas siguen verificables.
En acuerdos nuevos la autoria PQ la aporta, SI EXISTE, la co-firma COLD (air-gapped).
Huella COLD esperada: 8453a25a41d6fe8fcb5647600f042a7c303daaca79b80928534025711981c6a1
CONTRASTALA fuera de este ZIP: un bundle falso trae su propia clave y huella coherentes.
